import { Component,OnInit } from '@angular/core';
import {NgForm} from '@angular/forms';
import { Insta } from './insta';
import { InstaServiceService } from './insta-service.service';


@Component({
  selector: 'app-insta-list',
  templateUrl: './insta.component.html'
})

// tslint:disable-next-line: class-name
export class instaComponent implements OnInit {
	user: Insta[];
  newUser: Insta = new Insta();
  //editing: boolean = false;
  editingUser: Insta = new Insta();
  editingIndex: number = -1;
  searchText : string;

	constructor(
	  private instaService: InstaServiceService,
	) {}

	ngOnInit(): void {
		this.getUser();
  }

  getUser(): void {
    this.instaService.getUser()
      .then(users => this.user = users);
  }


  createUser(instaForm: NgForm): void {
    this.instaService.createUser(this.newUser)
      .then(createUser => {
      //  instaForm.reset();
        this.getUser();
	      // tslint:disable-next-line: indent
	      this.newUser = new Insta();
      });
  }

  deleteUser(id: number): void {
  	 this.instaService.deleteUser(id)
  	.then(() => {
  		this.user = this.user.filter(users => users.id !== id);
    });

  }

  editUser(user: Insta, i :number ): void {
   // this.editing = true;
    this.editingIndex = i;
    Object.assign(this.editingUser, user);
  }

  updateUser(user: Insta): void {
  	this.instaService.updateUser(user)
  	.then(() => {
  		Object.assign(this.user[this.editingIndex],this.editingUser)
      this.clearEditing();
  	});
  }


  clearEditing(): void {
    this.editingUser = new Insta();
    this.editingIndex=-1;
  }

  searchUser():void{
   this.instaService.searchUser(this.searchText).then(users => this.user = users);
  }

}

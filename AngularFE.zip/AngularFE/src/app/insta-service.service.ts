import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Insta } from './insta';

@Injectable({
  providedIn: 'root'
})

export class InstaServiceService {

  private baseUrl = 'http://localhost:10000';

  constructor(private http: HttpClient) { }

  getUser(): Promise<Insta[]> {
    return this.http.get(this.baseUrl + '/insta/user/')
      .toPromise()
      .then(response => response as Insta[])
      .catch(this.handleError);
  }

  createUser(user: Insta): Promise<Insta> {
    console.log(user);
    return this.http.post(this.baseUrl + '/insta/user/', user)
      .toPromise().then(response => response as Insta)
      .catch(this.handleError);
  }

  deleteUser(id: number): Promise<any> {
    return this.http.delete(this.baseUrl + '/insta/user/' + id)
      .toPromise()
      .catch(this.handleError);
  }

  updateUser(user: Insta): Promise<Insta> {
    return this.http.put(this.baseUrl + '/insta/user/' + user.id, user)
      .toPromise()
      .then(response => response as Insta)
      .catch(this.handleError);
  }

  searchUser(pattern:string ): Promise<Insta[]> {
    return this.http.get(this.baseUrl + '/insta/user/'+pattern)
      .toPromise()
      .then(response => response as Insta[])
      .catch(this.handleError);
  }


  private handleError(error: any): Promise<any> {
    console.error('Some error occured', error);
    return Promise.reject(error.message || error);
  }

}

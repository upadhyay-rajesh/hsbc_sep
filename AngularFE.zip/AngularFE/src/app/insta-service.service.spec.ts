import { TestBed } from '@angular/core/testing';

import { InstaServiceService } from './insta-service.service';

describe('InstaServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: InstaServiceService = TestBed.get(InstaServiceService);
    expect(service).toBeTruthy();
  });
});

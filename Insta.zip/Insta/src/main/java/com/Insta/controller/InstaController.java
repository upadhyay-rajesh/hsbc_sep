package com.Insta.controller;

import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Insta.dao.DaoInterface;
import com.Insta.entity.InstaUser;



@RestController
@RequestMapping("/insta")
@CrossOrigin("*")
public class InstaController {
	
	
	  @Autowired 
	  DaoInterface d;
	 
	
	@GetMapping("user")
	public List<InstaUser> viewProfile(){
		
		//List<InstaUser> l=d.viewProfileDao();
		List<InstaUser> l= new ArrayList<InstaUser>();
		 l=d.viewProfileDao();
		 
			/*
			 * InstaUser e1=new InstaUser();
			 * 
			 * e1.setName("akspreet"); e1.setPassword("aks"); e1.setEmail("aks@gmail.com");
			 * e1.setAddress("punjab");
			 * 
			 * InstaUser e2=new InstaUser(); e2.setName("abc"); e2.setPassword("xyz");
			 * e2.setEmail("abc@gmail.com"); e2.setAddress("hsp");
			 * 
			 * l.add(e1); l.add(e2);
			 */
		 return l;
	}
	
	
	 @DeleteMapping(value="/user/{id}")
    public void deleteTodo(@PathVariable("id") int id) {
        d.deleteProfileDao(id);
    }
	
	 @PostMapping("/user")
	    public void createTodo( @RequestBody InstaUser user) {
	     	d.createProfileDao(user);   
	  
	    }
	 
	 
	 @PutMapping(value="/user/{id}")
		public void editprofile(@RequestBody InstaUser u,@PathVariable("id") int id) throws Exception {

				d.editProfileDao(u, id);

		}
	 
	 @GetMapping("/user/{pattern}")
		public List<InstaUser> searchProfile(@PathVariable("pattern") String pattern){
			
			//List<InstaUser> l=d.viewProfileDao();
			List<InstaUser> l= new ArrayList<InstaUser>();
			 l=d.searchProfileDao(pattern);
			 
				/*
				 * InstaUser e1=new InstaUser();
				 * 
				 * e1.setName("akspreet"); e1.setPassword("aks"); e1.setEmail("aks@gmail.com");
				 * e1.setAddress("punjab");
				 * 
				 * InstaUser e2=new InstaUser(); e2.setName("abc"); e2.setPassword("xyz");
				 * e2.setEmail("abc@gmail.com"); e2.setAddress("hsp");
				 * 
				 * l.add(e1); l.add(e2);
				 */
			 return l;
		} 

}

package com.Insta.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.Insta.entity.InstaUser;



@Repository
public class InstaDao implements DaoInterface {

	
	public List<InstaUser> viewProfileDao() {
		// TODO Auto-generated method stub
		
			// TODO Auto-generated method stub
			List<InstaUser> l=new ArrayList<InstaUser>();
			
			
			Connection con=null;
			
			try {
				Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
				con=DriverManager.getConnection("jdbc:derby:d:/firstdb1;create=true","akspreet","aks");
				
				PreparedStatement ps;
				
					ps = con.prepareStatement("select id,name,password,email from instagram");
			
				
				ResultSet res=ps.executeQuery();
				
				
				while(res.next()) {
					InstaUser uu=new InstaUser();
					uu.setId(res.getInt(1));
					uu.setName(res.getString(2));
					uu.setPassword(res.getString(3));
					uu.setEmail(res.getString(4));
					
					l.add(uu);
			}
			}catch (ClassNotFoundException|SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			return l;

	}
	
	public void deleteProfileDao(int id){
		// TODO Auto-generated method stub
		Connection con=null;
		int i=0;
		try {
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		con=DriverManager.getConnection("jdbc:derby:d:/firstdb1;create=true","akspreet","aks");
		PreparedStatement ps=con.prepareStatement("delete from  instagram where id=?");
		ps.setInt(1,id);
		i=ps.executeUpdate();
		}
		
		catch(ClassNotFoundException | SQLException e1) {
			e1.printStackTrace();
		}
		
			
	}
	
		public void createProfileDao(InstaUser u) {
		Connection con=null;
		int i=0;
		try {
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		//Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		//creating connection
		con= DriverManager.getConnection("jdbc:derby:d:/firstdb1;create=true","akspreet","aks");
		
		PreparedStatement ps=con.prepareStatement("insert into instagram(name,password,email) values(?,?,?)");
		ps.setString(1, u.getName());
		ps.setString(2, u.getPassword());
		ps.setString(3, u.getEmail());
		//ps.setString(4, u.getAddress());
		
		 i=ps.executeUpdate();
		}
		catch(ClassNotFoundException | SQLException e1){
			e1.printStackTrace();
			
		}
		finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
		
		
		public void editProfileDao(InstaUser user, int id) {
			int i=0;
			Connection con=null;
			try {
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
			con= DriverManager.getConnection("jdbc:derby:d:/firstdb1;create=true","akspreet","aks");
			PreparedStatement ps=con.prepareStatement("update instagram set name=?, password=?, email=? where id=?");
			ps.setString(2, user.getPassword());
			ps.setInt(4, id);
			ps.setString(1, user.getName());
			ps.setString(3, user.getEmail());
			//System.out.println("hello");
			i= ps.executeUpdate();
			//System.out.println("how r u");

			}
			catch(ClassNotFoundException |SQLException e1) {
				e1.printStackTrace();
			}
		}
		
		public List<InstaUser> searchProfileDao(String pattern) {
			// TODO Auto-generated method stub
			
				// TODO Auto-generated method stub
				List<InstaUser> l=new ArrayList<InstaUser>();
				
				
				Connection con=null;
				
				try {
					Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
					con=DriverManager.getConnection("jdbc:derby:d:/firstdb1;create=true","akspreet","aks");
					
					PreparedStatement ps;
					
						ps = con.prepareStatement("select id,name,password,email from instagram where name like ?");
						ps.setString(1, pattern+'%');
					
					ResultSet res=ps.executeQuery();
					
					
					while(res.next()) {
						InstaUser uu=new InstaUser();
						uu.setId(res.getInt(1));
						uu.setName(res.getString(2));
						uu.setPassword(res.getString(3));
						uu.setEmail(res.getString(4));
						
						l.add(uu);
				}
				}catch (ClassNotFoundException|SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				return l;

		}
}

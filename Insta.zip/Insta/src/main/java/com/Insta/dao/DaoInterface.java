package com.Insta.dao;

import java.util.List;

import com.Insta.entity.InstaUser;

public interface DaoInterface {
	
	public List<InstaUser> viewProfileDao();



	void deleteProfileDao(int n);



	void createProfileDao(InstaUser u);



	public void editProfileDao(InstaUser u, int n);



	public List<InstaUser> searchProfileDao(String pattern);
	
}

package com.springdemo;

public class Trainer implements TrainerInterface {
	private LibraryInterface li;
	
	
	public void setLi(LibraryInterface li) {
		this.li = li;
	}


	public void teach() {
		System.out.println("teaching java");
		li.issuebooks();
	}
}

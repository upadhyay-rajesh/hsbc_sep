package com.springdemo;

public interface TrainerInterface {
	public void teach();
}

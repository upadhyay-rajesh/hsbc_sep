package com.springdemo;

public class Library implements LibraryInterface{
	public void issuebooks() {
		System.out.println("book issued");
	}
}

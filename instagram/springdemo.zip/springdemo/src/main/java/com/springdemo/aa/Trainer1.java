package com.springdemo.aa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.springdemo.LibraryInterface;
import com.springdemo.TrainerInterface;

@Component("tt1")
public class Trainer1 implements TrainerInterface {
	@Autowired
	private LibraryInterface li;
	
	

	public void teach() {
		System.out.println("trainer 1 teaching java");
		li.issuebooks();
	}
}

package com.springdemo;

public interface LibraryInterface {
	public void issuebooks();
}

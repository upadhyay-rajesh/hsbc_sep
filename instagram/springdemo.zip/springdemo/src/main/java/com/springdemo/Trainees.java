package com.springdemo;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Trainees {
	
	private TrainerInterface ti;
	
		
	private LibraryInterface li;
	
	
	/*
	 * public Trainees(TrainerInterface ti) {//ADAPTER this.ti=ti; }
	 * 
	 * 
	 */
	
	
	
	public void setLi(LibraryInterface li) {
		this.li = li;
	}

	public void setTi(TrainerInterface ti) { //adapter
		this.ti = ti;
	}

	public void useTrainer() {
		ti.teach();
		li.issuebooks();
	}
	
	public void useliberary() {
		
		li.issuebooks();
	}

	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("abc.xml");		
		Trainees tt=(Trainees)ctx.getBean("def");
		
	
		
		//TrainerInterface ti1=new Trainer();
		//tt.setTi(ti1);   //DI
		
		tt.useTrainer();
		tt.useliberary();
	}
}

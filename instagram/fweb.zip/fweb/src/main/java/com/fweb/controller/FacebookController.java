package com.fweb.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.*;

@Controller
public class FacebookController {
	
	@RequestMapping("cprofile.htm")
	public ModelAndView createProfile(@RequestParam("name") String name,@RequestParam("password") String pass,@RequestParam("email") String em,@RequestParam("address") String ad) {
		
	
		ModelAndView mv=new ModelAndView();
		mv.addObject("p1", name);
		mv.addObject("p2", pass);
		mv.addObject("p3", em);
		mv.addObject("p4", ad);
		
		mv.setViewName("result.jsp");
		
		return mv;
	}
	
	@RequestMapping("dprofile.htm")
	public ModelAndView deleteProfile() {
		ModelAndView mv=new ModelAndView();
		return mv;
	}
	
	@RequestMapping("vprofile.htm")
	public ModelAndView viewProfile() {
		ModelAndView mv=new ModelAndView();
		return mv;
	}
}

package com.fweb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.fweb.entity.FacebookEmployee;
import com.fweb.service.FacebookServiceInterface;

import javax.servlet.http.*;

@Controller
public class FacebookController {
	
	@Autowired
	private FacebookServiceInterface fs;
	
	@RequestMapping("cprofile.htm")
	public ModelAndView createProfile(@RequestParam("name") String name,@RequestParam("password") String pass,@RequestParam("email") String em,@RequestParam("address") String ad) {
		
		
		FacebookEmployee fe=new FacebookEmployee();
		fe.setName(name);
		fe.setPassword(pass);
		fe.setEmail(em);
		fe.setAddress(ad);
		
		int i=fs.createprofile(fe);
		String s="Registration Fail";
		if(i>0) {
			s="Registration Success";
		}
	
		ModelAndView mv=new ModelAndView();
		mv.addObject("p1", s);
				
		mv.setViewName("result.jsp");
		
		return mv;
	}
	
	@RequestMapping("dprofile.htm")
	public ModelAndView deleteProfile() {
		ModelAndView mv=new ModelAndView();
		return mv;
	}
	
	@RequestMapping("vprofile.htm")
	public ModelAndView viewProfile() {
		ModelAndView mv=new ModelAndView();
		return mv;
	}
}

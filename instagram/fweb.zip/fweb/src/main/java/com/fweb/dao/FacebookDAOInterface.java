package com.fweb.dao;

import com.fweb.entity.FacebookEmployee;

public interface FacebookDAOInterface {
	public int createprofiledao(FacebookEmployee fe);
}

package com.fweb.dao;

import org.springframework.stereotype.Repository;

import com.fweb.entity.FacebookEmployee;

@Repository
public class FacebookDAO implements FacebookDAOInterface{

	@Override
	public int createprofiledao(FacebookEmployee fe) {
		// TODO Auto-generated method stub
		return 1;
	}

}

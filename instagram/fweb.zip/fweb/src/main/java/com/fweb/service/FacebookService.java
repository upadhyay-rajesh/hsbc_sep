package com.fweb.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.fweb.dao.FacebookDAOInterface;
import com.fweb.entity.FacebookEmployee;

@Component
public class FacebookService implements FacebookServiceInterface{
	
	@Autowired
	private FacebookDAOInterface fd;
	

	@Override
	public int createprofile(FacebookEmployee e) {
		// TODO Auto-generated method stub
		return fd.createprofiledao(e);
	}
	
	

}

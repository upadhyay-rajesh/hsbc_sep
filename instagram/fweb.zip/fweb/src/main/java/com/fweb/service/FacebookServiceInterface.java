package com.fweb.service;

import com.fweb.entity.FacebookEmployee;

public interface FacebookServiceInterface {
	public int createprofile(FacebookEmployee e);
}

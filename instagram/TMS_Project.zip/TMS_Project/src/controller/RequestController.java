package controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.sql.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import dao.*;
import entity.*;

@Controller
@RequestMapping("/*")
public class RequestController {
	private EmployeeDAO empDAO;
	private TaskDAO obj;
	private ApprovalTaskDAO aptskdao;

	public void setEmpDAO(EmployeeDAO empDAO) {
		this.empDAO = empDAO;
	}

	public void setObj(TaskDAO obj) {
		this.obj = obj;
	}

	public void setAptskdao(ApprovalTaskDAO aptskdao) {
		this.aptskdao = aptskdao;
	}

	@RequestMapping("Validate.htm")
	public ModelAndView handleValidateRequest(HttpServletRequest req,
			HttpServletResponse resp) throws Exception {

		String email = req.getParameter("email");
		String pwd = req.getParameter("password");

		if (email.equals("admin") && pwd.equals("admin")) {
			return new ModelAndView("adminResp.jsp", "message", email);
		}

		Employee u = empDAO.serchByEmailAndPwd(email, pwd);
		ModelAndView m = new ModelAndView();
		
		if (u == null) {
			m.setViewName("loginResp.jsp");
			m.addObject("message", null);
			return m;
		} else {
			m.setViewName("loginResp.jsp");
			m.addObject("message", u);
			return m;
		}
	}

	@RequestMapping("emailGeneration.htm")
	public ModelAndView handleEmailGenerationRequest(HttpServletRequest req,
			HttpServletResponse resp) throws Exception {

		String fname = req.getParameter("fname");
		String lname = req.getParameter("lname");
		System.out.println(fname + " " + lname);

		Integer i = 0;
		Employee emp;
		String email;
		do {
			i++;
			email = fname + "_" + lname + i + "@taskflick.com";

			emp = empDAO.serchByEmail(email);
		} while (emp != null);

		ModelAndView m = new ModelAndView();
		m.setViewName("EmailGenerationResp.jsp");
		m.addObject("message", email);
		return m;

	}

	@RequestMapping("SaveReg.htm")
	public ModelAndView handleRegistrationRequest(HttpServletRequest req,
			HttpServletResponse resp) throws Exception {

		String fname = req.getParameter("fname");
		String lname = req.getParameter("lname");
		String password = req.getParameter("password");
		String phoneNo = req.getParameter("phoneNo");
		String imgpath = req.getParameter("imgpath");
		System.out.println(imgpath);
		String address = req.getParameter("address");
		String email = req.getParameter("email");

		Employee emp = new Employee();
		emp.setFname(fname);
		emp.setLname(lname);
		emp.setEmailid(email);
		emp.setImgpath(imgpath);
		emp.setPassword(password);
		emp.setAddress(address);
		emp.setPhno(phoneNo);
		boolean result = empDAO.insert(emp);
		String message = "Registration Failed";
		String filename = "RegisterFail";
		if (result == true) {
			message = "Registration Successfull";
			filename = "RegisterSuccess";
		}
		ModelAndView m = new ModelAndView();
		m.setViewName(filename + ".jsp");
		m.addObject("message", message);
		return m;

	}

	@RequestMapping("updateProfile.htm")
	public ModelAndView handleUpdateProfileRequest(HttpServletRequest req,
			HttpServletResponse resp) throws Exception {

		String password = req.getParameter("nPwd");
		String phoneNo = req.getParameter("nPhno");
		String imgpath = req.getParameter("nPic");
		String address = req.getParameter("nAdd");
		System.out.println(password + "  " + phoneNo + "  " + imgpath + "  "
				+ address);

		HttpSession hs = req.getSession();
		Employee e = (Employee) hs.getAttribute("emp");
		// System.out.println("hi"+imgpath +"hello");
		// System.out.println(e.getImgpath());
		if (imgpath.isEmpty())
			imgpath = e.getImgpath();
		System.out.println(imgpath);

		if (!(imgpath.isEmpty()))
			e.setImgpath(imgpath);
		System.out.println(e.getImgpath());
		e.setPassword(password);
		e.setAddress(address);
		e.setPhno(phoneNo);
		boolean result = empDAO.updateEmployee(e);
		String message = "Updation Failed";

		if (result == true) {
			message = "Updated Your Profile Successfully";

		}
		ModelAndView m = new ModelAndView();
		m.setViewName("updateDetails.jsp");
		m.addObject("message", message);
		return m;

	}

	@RequestMapping("searchlist.htm")
	public ModelAndView handleSearchRequest(HttpServletRequest req,
			HttpServletResponse resp) throws Exception {

		String value = req.getParameter("searchtype");
		String fir = req.getParameter("fir");

		List<Employee> emp = new ArrayList<Employee>();
		Employee e;
		String message = "NOT FOUND";
		ModelAndView mv = new ModelAndView();
		mv.setViewName("search.jsp");
		if (value.equals("emailid")) {

			e = empDAO.serchByEmail(fir);
			emp.add(e);
			mv.addObject("message", emp);
		} else if (value.equals("fname")) {
			emp = (List<Employee>) empDAO.serchByFname(fir);
			mv.addObject("message", emp);
		} else if (value.equals("lname")) {
			emp = (List<Employee>) empDAO.serchByLname(fir);
			mv.addObject("message", emp);

		}
		if (emp.size() == 0) {
			mv.addObject("type", "notfound");
		} else {
			mv.addObject("type", "list");
		}
		return mv;

	}

	@RequestMapping("day2day.htm")
	public ModelAndView handledaytoday(HttpServletRequest req,
			HttpServletResponse resp) throws Exception {

		HttpSession sess = req.getSession(true);
		Employee emp = (Employee) sess.getAttribute("emp");

		List<? extends Task> tsk = (List<? extends Task>) obj
				.srchTskNtCmptByEmp(emp.getEmpid());
		ModelAndView mv = new ModelAndView();
		mv.addObject("tasklist", tsk);
		mv.setViewName("dayToDay.jsp");
		return mv;
	}

	@RequestMapping("getTasktoAssign.htm")
	public ModelAndView handleTaskListtoAssign(HttpServletRequest req,
			HttpServletResponse resp) throws Exception {

		List<? extends Employee> emplist = (List<? extends Employee>) obj
				.searchNotAssignedEmp();
		List<? extends Task> tsk = (List<? extends Task>) obj
				.searchByCurrentStatus("unassigned");
		ModelAndView mv = new ModelAndView();
		mv.addObject("emplist", emplist);
		mv.addObject("tasklist", tsk);
		mv.setViewName("assignTask.jsp");
		return mv;
	}

	@RequestMapping("registerTask.htm")
	public ModelAndView handleAddTaskRequest(HttpServletRequest req,
			HttpServletResponse resp) throws Exception {

		String taskname = req.getParameter("taskname");
		String desc = req.getParameter("description");
		// String sdate=req.getParameter("sdate");
		String edate = req.getParameter("edate");
		System.out.println(edate);
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date eDate = null;
		// System.out.println(eDate);
		Date endDate = null;
		try {

			eDate = df.parse(edate);
			System.out.println(eDate);
			endDate = new Date(eDate.getTime());
		} catch (ParseException e) {
			e.printStackTrace();

		}

		Task tsk = new Task();
		tsk.setCurrentstatus("unassigned");
		tsk.setDescription(desc);
		tsk.setTaskname(taskname);
		tsk.setEdate(endDate);
		boolean result = obj.insert(tsk);
		String message = "Task NotAdded";
		String filename = "RegisterFail";
		if (result == true) {
			message = "Task Added";
			filename = "RegisterSuccess";
		}
		ModelAndView mv = new ModelAndView();
		mv.addObject("message", message);
		mv.setViewName(filename+".jsp");
		return mv;
	}

	@RequestMapping("allocatetask.htm")
	public ModelAndView handleAllocateTaskRequest(HttpServletRequest req,
			HttpServletResponse resp) throws Exception {

		Long empid = Long.parseLong(req.getParameter("empid"));
		Long taskid = Long.parseLong(req.getParameter("taskid"));

		Task tsk = obj.searchByTaskId(taskid);
		Employee emp = empDAO.searchByEmpid(empid);
		boolean flag = obj.assignTask(tsk, emp);
		String s="";
		if (flag)
			s="task assigned";
			
		else
			s="task not assigned";
		ModelAndView mv = new ModelAndView();
		mv.addObject("message", s);
		mv.setViewName("assignTask.jsp");
		return mv;

	}

	@RequestMapping("modifyStatus.htm")
	public ModelAndView handleModifyStatusRequest(HttpServletRequest req,
			HttpServletResponse resp) throws Exception {
		String taskStatus = req.getParameter("statusReq");
		Long taskid = Long.parseLong(req.getParameter("taskid"));
		ModelAndView mv = new ModelAndView();
		
		mv.setViewName("dayToDay.jsp");
		if (taskStatus.equals("delayrequest")) {
			Integer days = Integer.parseInt(req.getParameter("days"));
			if (obj.modifytaskstatus(taskid, taskStatus)) {
				ApprovalTask aptask = new ApprovalTask();
				aptask.setDays(days);
				aptask.setTaskid(taskid);
				if (aptskdao.insert(aptask)){
					mv.addObject("message", "Delay Request Sent ");
					return mv;
				}
			}
			mv.addObject("message", " Delay Request Not Sent ");
			return mv;
		} else {
			if (obj.modifytaskstatus(taskid, taskStatus)){
				mv.addObject("message", "Request Sent ");
				return mv;
				
			}
			else{
				mv.addObject("message", "Request Not Sent ");
				return mv;
			}
		}
		
	}

	@RequestMapping("getApprovalTask.htm")
	public ModelAndView handleApprovalTaskRequest(HttpServletRequest req,
			HttpServletResponse resp) throws Exception {

		List<? extends Task> tsklist = (List<? extends Task>) obj
				.searchByCurrentStatus("delayrequest");
		List<? extends ApprovalTask> aptasklist = (List<? extends ApprovalTask>) aptskdao
				.listUnhandledTask();

		ModelAndView mv = new ModelAndView();
		mv.addObject("aptasklist", aptasklist);
		mv.addObject("tasklist", tsklist);
		mv.setViewName("approvalTask.jsp");
		return mv;
	}

	@RequestMapping("approveTask.htm")
	public ModelAndView handleApproveTaskRequest(HttpServletRequest req,
			HttpServletResponse resp) throws Exception {
		String adminstatus = req.getParameter("adminstatus");
		Long approvaltaskid = Long
				.parseLong(req.getParameter("approvaltaskid"));
		System.out.println(adminstatus + approvaltaskid);
		String s="";
		ApprovalTask aptask = aptskdao.searchByappTaskId(approvaltaskid);

		if (aptskdao.changeAdminStatus(aptask.getTaskid(), adminstatus)) {
			obj.modifytaskstatus(aptask.getTaskid(), "assigned");
			Task tsk = obj.searchByTaskId(aptask.getTaskid());
			if (adminstatus.equals("approve")) {
				Date edate = tsk.getEdate();
				System.out.println(edate);

				int days = aptask.getDays();
				int date = edate.getDate();
				date += days;
				edate.setDate(date);
				System.out.println(edate);

				if (obj.setDate(tsk, edate)) 
					s=adminstatus;
					
			} else {

				s=adminstatus;
			}

		}
		s="Not "+adminstatus;
		ModelAndView mv = new ModelAndView();
		mv.addObject("message", s);
		mv.setViewName("approveTask.jsp");
		return mv;
	}

	@RequestMapping("logout.htm")
	public ModelAndView handleLogOutRequest(HttpServletRequest req,
			HttpServletResponse resp) throws Exception {
		ModelAndView mv = new ModelAndView();
		mv.addObject("message", "You are logged out");
		mv.setViewName("logout.jsp");
		return mv;
		
	}

	@RequestMapping("getEmpForReport.htm")
	public ModelAndView handlegetEmpForReport(HttpServletRequest req,
			HttpServletResponse resp) throws Exception {

		List<? extends Employee> emplist = (List<? extends Employee>) empDAO
				.selectAll();
		ModelAndView mv = new ModelAndView();
		mv.addObject("emplist", emplist);
		mv.setViewName("menuReport.jsp");
		return mv;
	}

	@RequestMapping("generateReport.htm")
	public ModelAndView handlegetgenerateReport(HttpServletRequest req,
			HttpServletResponse resp) throws Exception {
		Long empid = null;
		if (req.getParameter("empid") == null) {
			HttpSession sess = req.getSession(true);
			Employee emp = (Employee) sess.getAttribute("emp");
			empid = emp.getEmpid();
		} else
			empid = Long.parseLong(req.getParameter("empid"));

		String edate = req.getParameter("edate");
		String sdate = req.getParameter("sdate");

		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date eDate = null;

		Date endDate = null;
		java.util.Date sDate = null;

		Date startDate = null;
		try {

			eDate = df.parse(edate);

			endDate = new Date(eDate.getTime());
			sDate = df.parse(sdate);

			startDate = new Date(sDate.getTime());
		} catch (ParseException e) {
			e.printStackTrace();

		}

		List<? extends Task> tasklist = obj.TaskByEmpDuringPeriod(empid,
				startDate, endDate);
		ModelAndView mv = new ModelAndView();
		mv.addObject("tasklist", tasklist);
		mv.addObject("message", "report");
		mv.setViewName("report.jsp");
		return mv;

	}

}

package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import entity.ApprovalTask;

public class ApprovalTaskDAOImpl implements ApprovalTaskDAO {
	private EntityManagerFactory entityManagerFactory;
	private EntityManager em;
	EntityTransaction t;

	public void setEntityManagerFactory(
			EntityManagerFactory entityManagerFactory) {
		this.entityManagerFactory = entityManagerFactory;
	}

	public void init() {

		em = entityManagerFactory.createEntityManager();
		t = em.getTransaction();
	}

	public boolean changeAdminStatus(long taskid, String adminstatus) {
		init();
		Query query = em
				.createQuery("SELECT tsk FROM ApprovalTask tsk WHERE tsk.taskid= ?1 and tsk.adminstatus IS NULL");
		query.setParameter(1, taskid);
		// query.setParameter(1, empid);
		ApprovalTask ts;
		boolean flag = false;
		try {
			ts = (ApprovalTask) query.getSingleResult();
		} catch (javax.persistence.NoResultException e) {
			ts = null;
		}
		if (ts == null)
			return flag;
		else {
			ts.setAdminstatus(adminstatus);
			t.begin();
			em.merge(ts);
			t.commit();
			flag = true;
			return flag;
		}
	}

	public boolean remove(long taskid) {
		init();
		Query que = em
				.createQuery("Select e from ApprovalTask e where e.taskid= ?1");
		que.setParameter(1, taskid);
		ApprovalTask ts;
		boolean flag = false;
		try {
			ts = (ApprovalTask) que.getSingleResult();

		} catch (javax.persistence.NoResultException e) {
			ts = null;
			e.printStackTrace();
			return false;
		}
		t.begin();
		em.remove(ts);
		t.commit();
		flag = true;
		return flag;

	}

	public List<? extends ApprovalTask> searchByAdminStatus(String adminstatus) {
		init();
		Query query = em
				.createQuery("SELECT tsk FROM ApprovalTask tsk WHERE tsk.adminstatus= ?1");
		query.setParameter(1, adminstatus);
		List<ApprovalTask> tskList = (List<ApprovalTask>) query.getResultList();
		return tskList;
	}

	public ApprovalTask searchByTaskId(long taskid) {
		init();
		Query que = em
				.createQuery("Select e from ApprovalTask e where e.taskid= ?1");
		que.setParameter(1, taskid);
		ApprovalTask ts;
		try {
			ts = (ApprovalTask) que.getSingleResult();
		} catch (javax.persistence.NoResultException e) {
			ts = null;
		}
		return ts;
	}

	public boolean insert(ApprovalTask aptask) {

		boolean b = false;
		init();
		t.begin();
		em.persist(aptask);
		t.commit();

		b = true;
		return b;
	}

	public ApprovalTask searchByappTaskId(long apptaskid) {
		init();
		Query que = em
				.createQuery("Select e from ApprovalTask e where e.approvaltaskid= ?1");
		que.setParameter(1, apptaskid);
		ApprovalTask ts;
		try {
			ts = (ApprovalTask) que.getSingleResult();
		} catch (javax.persistence.NoResultException e) {
			ts = null;
		}
		return ts;
	}

	public List<? extends ApprovalTask> listUnhandledTask() {
		init();
		Query query = em
				.createQuery("SELECT tsk FROM ApprovalTask tsk WHERE tsk.adminstatus IS NULL");
		List<ApprovalTask> tskList = (List<ApprovalTask>) query.getResultList();
		return tskList;
	}

}

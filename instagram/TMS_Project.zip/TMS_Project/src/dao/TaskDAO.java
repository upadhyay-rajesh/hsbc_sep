package dao;

import entity.*;

import java.sql.Date;
import java.util.List;

import entity.Task;

public interface TaskDAO {
	public void init();

	public Task searchByTaskId(long taskid);

	public List<? extends Task> searchByEmpId(long empid);

	public List<? extends Task> searchByCurrentStatus(String currentstatus);

	public boolean insert(Task tk);

	public boolean modifytaskstatus(long taskid, String status);

	public List<? extends Employee> searchNotAssignedEmp();

	public boolean assignTask(Task tsk, Employee emp);

	public List<? extends Task> srchTskNtCmptByEmp(long empid);

	public boolean setDate(Task task, Date date);

	public List<? extends Task> TaskByEmpDuringPeriod(long empid, Date start,
			Date end);

}

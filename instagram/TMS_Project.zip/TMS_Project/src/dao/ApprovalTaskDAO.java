package dao;

import java.util.List;

import entity.ApprovalTask;

public interface ApprovalTaskDAO {

	boolean changeAdminStatus(long taskid, String adminstatus);

	List<? extends ApprovalTask> searchByAdminStatus(String adminstatus);

	ApprovalTask searchByTaskId(long taskid);

	boolean remove(long taskid);

	boolean insert(ApprovalTask aptask);

	ApprovalTask searchByappTaskId(long apptaskid);

	List<? extends ApprovalTask> listUnhandledTask();

}

package dao;

import java.sql.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.TemporalType;

import entity.Employee;
import entity.Task;

public class TaskDAOImpl implements TaskDAO {
	private EntityManagerFactory entityManagerFactory;
	private EntityManager em;
	EntityTransaction t;

	public void setEntityManagerFactory(
			EntityManagerFactory entityManagerFactory) {
		this.entityManagerFactory = entityManagerFactory;
	}

	public void init() {

		em = entityManagerFactory.createEntityManager();
		t = em.getTransaction();
	}

	public boolean insert(Task tk) {
		boolean b = false;
		init();
		t.begin();
		em.persist(tk);
		t.commit();

		b = true;
		return b;
	}

	public Task searchByTaskId(long taskid) {
		init();
		Query que = em.createQuery("Select e from Task e where e.taskid= ?1");
		que.setParameter(1, taskid);
		Task ts;
		try {
			ts = (Task) que.getSingleResult();
		} catch (javax.persistence.NoResultException e) {
			ts = null;
		}
		return ts;
	}

	public boolean modifytaskstatus(long taskid, String status) {
		init();
		Query query = em
				.createQuery("SELECT tsk FROM Task tsk WHERE tsk.taskid= ?1");
		query.setParameter(1, taskid);
		// query.setParameter(1, empid);
		Task ts;
		boolean flag = false;
		try {
			ts = (Task) query.getSingleResult();
		} catch (javax.persistence.NoResultException e) {
			ts = null;
		}
		if (ts == null)
			return flag;
		else {
			ts.setCurrentstatus(status);
			t.begin();
			em.merge(ts);
			t.commit();
			flag = true;
			return flag;
		}
	}

	@SuppressWarnings("unchecked")
	public List<? extends Task> searchByCurrentStatus(String currentstatus) {
		init();
		Query query = em
				.createQuery("SELECT tsk FROM Task tsk WHERE tsk.currentstatus= ?1");
		query.setParameter(1, currentstatus);
		List<Task> tskList = query.getResultList();
		return tskList;
	}

	public List<? extends Task> searchByEmpId(long empid) {
		init();
		Query que = em.createQuery("Select e from Task e where e.empid= ?1");
		que.setParameter(1, empid);
		List<? extends Task> ts;
		try {
			ts = (List<? extends Task>) que.getResultList();
		} catch (javax.persistence.NoResultException e) {
			ts = null;
		}
		return ts;
	}

	public List<? extends Task> srchTskNtCmptByEmp(long empid) {
		init();
		Query que = em
				.createQuery("Select t from Task t where t.empid= ?1 and t.currentstatus != ?2");
		que.setParameter(1, empid);
		que.setParameter(2, "completed");
		List<? extends Task> ts;
		try {
			ts = (List<? extends Task>) que.getResultList();
			System.out.println(ts.size());
		} catch (javax.persistence.NoResultException e) {
			ts = null;
		}
		return ts;
	}

	public List<? extends Employee> searchNotAssignedEmp() {
		init();
		Query que = em
				.createQuery("select e from Employee e where not exists (select t.empid from Task t where e.empid=t.empid and t.currentstatus!='completed')");
		List<? extends Employee> ts;
		try {
			ts = (List<? extends Employee>) que.getResultList();
		} catch (javax.persistence.NoResultException e) {
			ts = null;
		}
		return ts;
	}

	public boolean assignTask(Task tsk, Employee emp) {
		boolean flag = false;
		init();
		java.util.Date d = new java.util.Date();
		Date sdate = new Date(d.getTime());
		tsk.setSdate(sdate);
		tsk.setCurrentstatus("assigned");
		tsk.setEmpid(emp.getEmpid());
		t.begin();
		em.merge(tsk);
		t.commit();
		flag = true;

		return flag;
	}

	public boolean setDate(Task task, Date date) {
		boolean flag = false;
		init();
		task.setEdate(date);
		t.begin();
		em.merge(task);
		t.commit();
		flag = true;

		return flag;
	}

	public List<? extends Task> TaskByEmpDuringPeriod(long empid, Date start,
			Date end) {
		init();
		return (List<? extends Task>) em.createQuery(
				"SELECT e " + "FROM Task e " + "WHERE e.empid =" + empid
						+ "  and e.sdate BETWEEN :start AND :end")

		.setParameter("start", start, TemporalType.DATE).setParameter("end",
				end, TemporalType.DATE).getResultList();
	}
}

package dao;

import java.util.List;

import entity.Employee;

public interface EmployeeDAO {
	public void init();

	public boolean insert(Employee e);

	public boolean checklogin(Employee e);

	public Employee serchByEmail(String email);

	public List<Employee> serchByFname(String fname);

	public List<Employee> serchByLname(String lname);

	public boolean updateEmployee(Employee e);

	public List<Employee> selectAll();

	public Employee serchByEmailAndPwd(String email, String pwd);

	public Employee searchByEmpid(long empid);
}

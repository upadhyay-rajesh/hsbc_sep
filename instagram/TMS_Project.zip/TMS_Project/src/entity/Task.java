package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

//import java.io.Serializable;
import java.sql.Date;

@Entity
@Table(name="Task")
public class Task{
	
	@Id	
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="TaskID") 
	private long taskid;
	
	@Column(name="TaskName")
	private String taskname;
	
	@Column(name="Description")
	private String description;
	
	@Column(name="StartDate")
	private Date sdate;
	
	@Column(name="EndDate")
	private Date edate;
	
	@Column(name="EmpId")
	private long empid;
	
	@Column(name="CurrentStatus")
	private String currentstatus;

	public String getTaskname() {
		return taskname;
	}

	public void setTaskname(String taskname) {
		this.taskname = taskname;
	}
	
	public long getTaskid() {
		return taskid;
	}
	
	public void setTaskid(long taskid) {
		this.taskid = taskid;
	}

	

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCurrentstatus() {
		return currentstatus;
	}

	public void setCurrentstatus(String currentstatus) {
		this.currentstatus = currentstatus;
	}

	public Date getSdate() {
		return sdate;
	}

	public void setSdate(Date sdate) {
		this.sdate = sdate;
	}

	public Date getEdate() {
		return edate;
	}

	public void setEdate(Date edate) {
		this.edate = edate;
	}

	public long getEmpid() {
		return empid;
	}

	public void setEmpid(long empid) {
		this.empid = empid;
	}
	
}

	
package entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ApprovalTask")

public class ApprovalTask {
	@Id	
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ApprovalTaskID") 
	private long approvaltaskid;
	@Column(name="TaskID") 
	private long taskid;
	
	@Column(name="Days") 
	private int days;
	
	@Column(name="AdminStatus") 
	private String adminstatus;

	public long getApprovaltaskid() {
		return approvaltaskid;
	}

	public void setApprovaltaskid(long approvaltaskid) {
		this.approvaltaskid = approvaltaskid;
	}

	public long getTaskid() {
		return taskid;
	}

	public void setTaskid(long taskid) {
		this.taskid = taskid;
	}

	public int getDays() {
		return days;
	}

	public void setDays(int days) {
		this.days = days;
	}

	public String getAdminstatus() {
		return adminstatus;
	}

	public void setAdminstatus(String adminstatus) {
		this.adminstatus = adminstatus;
	}
	

}

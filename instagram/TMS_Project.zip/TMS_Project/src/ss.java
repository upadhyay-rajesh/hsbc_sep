
public class ss {

	public static void main(String[] args) {
		

	}

}

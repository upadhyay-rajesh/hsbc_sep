package test;

import static org.junit.Assert.*;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import dao.EmployeeDAO;
import dao.EmployeeDAOImpl;
import entity.Employee;

public class TestEmployeeDAOiMPL {
	private Employee emp;
	private EmployeeDAOImpl empDAO;
	private EntityManagerFactory emf;
	@Before
	public void setUp() throws Exception {
		emp=new Employee();
		empDAO=new EmployeeDAOImpl();
		emf=Persistence.createEntityManagerFactory("springjpaPU1");
		empDAO.setEntityManagerFactory(emf);
	}

	@After
	public void tearDown() throws Exception {
		emp=null;
		empDAO=null;
		emf=null;
	}

	@Test
	public void testInsert() {
		emp.setFname("x");
		emp.setLname("x");
		emp.setEmailid("x");
		emp.setImgpath("x");
		emp.setPassword("x");
		emp.setAddress("x");
		emp.setPhno("2");
		boolean result=empDAO.insert(emp);
		assertTrue(result);
		
	}

	@Test
	public void testChecklogin() {
		System.out.println("Not yet implemented");
	}

	@Test
	public void testSerchByEmail() {
		System.out.println("Not yet implemented");
	}

	@Test
	public void testSerchByEmailAndPwd() {
		System.out.println("Not yet implemented");
	}

	@Test
	public void testSerchByFname() {
		System.out.println("Not yet implemented");
	}

	@Test
	public void testSerchByLname() {
		System.out.println("Not yet implemented");
	}

	@Test
	public void testUpdateEmployee() {
		System.out.println("Not yet implemented");
	}

	@Test
	public void testSelectAll() {
		System.out.println("Not yet implemented");
	}

	@Test
	public void testSearchByEmpid() {
		System.out.println("Not yet implemented");
	}

}

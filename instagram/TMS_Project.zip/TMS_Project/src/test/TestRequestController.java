package test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.web.servlet.ModelAndView;

import controller.RequestController;
import dao.ApprovalTaskDAO;
import dao.ApprovalTaskDAOImpl;
import dao.EmployeeDAO;
import dao.EmployeeDAOImpl;
import dao.TaskDAO;
import dao.TaskDAOImpl;
import entity.ApprovalTask;

public class TestRequestController {
	private MockHttpServletRequest request;
	private MockHttpServletResponse response;
	private MockHttpSession session;
	private ModelAndView modelAndView;
	private ApprovalTaskDAO atd;
	private EmployeeDAO ed;
	private TaskDAO td;
	private RequestController controller;
	@Before
	public void setUp() throws Exception {
		atd=new ApprovalTaskDAOImpl(); 
		ed=new EmployeeDAOImpl();
		td=new TaskDAOImpl();
		controller=new RequestController();
	}

	@After
	public void tearDown() throws Exception {
		atd=null;
		ed=null;
		td=null;
		
	}

	@Test
	public void testHandleValidateRequest() {
		System.out.println("Not yet implemented");
	}

	@Test
	public void testHandleEmailGenerationRequest() {
		try{
		request = new MockHttpServletRequest("GET", "/emailGeneration.htm");
		request.setParameter("fname", "ylee");
		request.setParameter("lname", "abc");
		modelAndView = controller.handleEmailGenerationRequest(request, response);
		}
		catch(Exception e){
			
			fail("exception");
		}
		assertEquals("EmailGenerationResp.jsp", modelAndView.getViewName());
		
	}

	@Test
	public void testHandleRegistrationRequest() {
		try{
		request = new MockHttpServletRequest("GET", "/SaveReg.htm");
		request.setParameter("fname","s");
		request.setParameter("lname","s");
		request.setParameter("password","s");
		request.setParameter("phoneno","123");
		request.setParameter("imgpath","s");
		request.setParameter("address","s");
		request.setParameter("email","s");
		modelAndView = controller.handleRegistrationRequest(request, response);
		}
		catch(Exception e){
			
			fail("exception");
		}
		assertEquals("RegisterSuccess.jsp", modelAndView.getViewName());
		
	}

	@Test
	public void testHandleUpdateProfileRequest() {
		System.out.println("Not yet implemented");
	}

	@Test
	public void testHandleSearchRequest() {
		System.out.println("Not yet implemented");
	}

	@Test
	public void testHandledaytoday() {
		System.out.println("Not yet implemented");
	}

	@Test
	public void testHandleTaskListtoAssign() {
		System.out.println("Not yet implemented");
	}

	@Test
	public void testHandleAddTaskRequest() {
		System.out.println("Not yet implemented");
	}

	@Test
	public void testHandleAllocateTaskRequest() {
		System.out.println("Not yet implemented");
	}

	@Test
	public void testHandleModifyStatusRequest() {
		System.out.println("Not yet implemented");
	}

	@Test
	public void testHandleApprovalTaskRequest() {
		System.out.println("Not yet implemented");
	}

	@Test
	public void testHandleApproveTaskRequest() {
		System.out.println("Not yet implemented");
	}

	@Test
	public void testHandleLogOutRequest() {
		System.out.println("Not yet implemented");
	}

	@Test
	public void testHandlegetEmpForReport() {
		System.out.println("Not yet implemented");
	}

	@Test
	public void testHandlegetgenerateReport() {
		System.out.println("Not yet implemented");
	}

}
